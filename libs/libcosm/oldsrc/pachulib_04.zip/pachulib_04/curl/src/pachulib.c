/***********************************************************************
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
( at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
ERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
Online: http://www.gnu.org/licenses/gpl.txt
***********************************************************************/

#include "../include/pachulib.h"

/*PRIVATE FUNCTIONS*/

//curl related:
static size_t write_data(void *ptr, size_t size, size_t nmemb, void *stream);
static size_t write_data_to_string(void *ptr, size_t size, size_t nmemb, void *stream);
//socket related
int resolve_host(char *host,char *ip);
int connect_server(int *fd);
void disconnect_server(int fd);
int read_data(int fd, char *buffer);
int send_data(int fd, char *buffer, unsigned int long_buffer);

//http status codes:
int recover_status(char *msg);
int recover_env_id_status(char *msg,unsigned int * env_id);
int recover_trigger_id_status(char * msg,unsigned int * tr_id);
int recover_env_from_http(char *msg, char *environment);
int find_in_http(char *msg, char *tag, int * position);

int data_format_str(data_format_tp format, char * format_str);


int save_file(char * file_name, char * datastream);


char * http_method_tp_str[] = {"POST","GET","PUT","DELETE",NULL};

char * data_format_tp_str[] = {"csv","json","xml","png","rss","atom",NULL};

char * trigger_tp_str[] ={"gt","gte","lt","lte","eq","change", NULL};

//TODO handle size errors
static size_t write_data_to_string(void *ptr, size_t size, size_t nmemb, void *stream)
{

	if (((char *)stream)[0]!='\0')
		sprintf((char *)stream,"%s%s",(char *)stream,(char *)ptr);
	else
		sprintf((char *)stream,"%s",(char *)ptr);

	return (strlen((char *)ptr));

}
//write get data to file: from libcurl code examples:
static size_t write_data(void *ptr, size_t size, size_t nmemb, void *stream)
{
  int written = fwrite(ptr, size, nmemb, (FILE *)stream);
  return written;
}


int data_format_str(data_format_tp format, char * format_str)
{
	if ((format<CSV)||(format>ATOM)) return FALSE;

	if (format == CSV)
		sprintf(format_str,"csv");
	else if (format == JSON)
		sprintf(format_str,"json");
	else if (format == XML)
		sprintf(format_str,"xml");
	else if (format == PNG)
		sprintf(format_str,"png");
	else if (format == RSS)
		sprintf(format_str,"rss");
	else if (format == ATOM)
		sprintf(format_str,"atom");

	return TRUE;

}

int save_file(char * file_name, char * datastream)
{

	FILE *ofp;
	ofp = fopen(file_name, "w+"); //create if not exists

	if (ofp == NULL) 
	{
	  perror("Can't open output file %s!\n");
	  return FALSE;
	}

	fprintf(ofp,"Data:\n\n%s\n\nEnd.",datastream);

	fflush(ofp);

	fclose(ofp);

	return TRUE;


}


int resolve_host(char * host, char *ip)
{
	struct hostent *he;

	if ((he=gethostbyname(host)) == NULL)   
        {
        	perror("Err!! gethostbyname");
	        return FALSE;
    	}

	if(inet_ntop(AF_INET, (void *)he->h_addr_list[0], ip, IP_MAX) == NULL) //16 = xxx.xxx.xxx.xxx + '\0' (ip)
	{
	    	perror("Err!! resolving host");
		return FALSE;
	}

	printf("host vale %s, ip %s\n",host, ip);
  	return TRUE;
}
//fd: socket descriptor
int connect_server(int *fd)
{
    	struct sockaddr_in direccion;
	char ip[IP_MAX]; //xxx.xxx.xxx.xxx. + '\0'


	if (!resolve_host(HOST,ip))
		return FALSE;

	if ((*fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) 
	{
		perror("Err!! socket");
		return FALSE;
	}
    	
	direccion.sin_family = AF_INET;    
	direccion.sin_port = htons(HTTP_PORT); 
	direccion.sin_addr.s_addr = inet_addr(ip);

    	memset(&(direccion.sin_zero), 8,0);  
    	if (connect(*fd, (struct sockaddr *)&direccion, sizeof(struct sockaddr)) == -1) 
	{
        	perror("Err!! connect");
	        return FALSE;
        }
	printf("connected\n");
	return TRUE;
}
void disconnect_server(int fd)
{
	close(fd);
	printf("disconnected\n");
}
int send_data(int fd, char *buffer, unsigned int long_buffer)
{
	int ret = 0;


	printf("\nSEND_DATA:\n%s\n",buffer);

	while (long_buffer)	
	{
		ret=send(fd, buffer, long_buffer, MSG_NOSIGNAL);

		if (ret == -1)
		{
			perror("Err! send");
			close(fd);
			return FALSE;
		}
		long_buffer-=ret;
		buffer+=ret;
	}
	return TRUE;
}
int read_data(int fd, char *buffer)
{

	int long_buffer = MSG_MAX;
	int ret = 0;
	
	char * ptoB = buffer;

	while (long_buffer>0)
	{
		ret=recv(fd, ptoB,long_buffer, MSG_NOSIGNAL);
		//printf("\nret %d, long %d\n",ret,long_buffer);
		//printf("recibido %s\n",buffer);
		if (ret<0)
		{
			perror("Err! recv");	
			close(fd);
			return FALSE;
		}
		if (ret == 0)
		{
			
			close(fd);
			if (long_buffer == MSG_MAX) //no-data
			{
				perror("Err!! desconexion en recv");			
				return FALSE;
			}
			*ptoB='\0';
			return TRUE;
			
		}
		long_buffer-=ret;
		ptoB+=ret;
		
	}
	return TRUE;
}
int recover_status(char *msg)
{

	
	//Server return codes:
	int return_code;

	printf("\n__READ_DATA:\n%s\nEND_DATA__\n",msg);

	if (sscanf(msg,"HTTP/1.1 %d*",&return_code) != 1) return FALSE;

	printf("HTTP return code : %d\n", return_code);

	if (return_code == RET_OK)
	{
		//printf("OK\n");	
		return TRUE;
	}
/* TODO 
#define RET_NOT_AUTH 401
#define RET_FORBIDDEN 403
#define RET_NOT_FOUND 404
#define RET_UNPROCESSABLE_ENTITY 422
#define RET_INTERNAL_SERVER_ERROR 500
#define RET_NO_SERVER_ERROR 503
*/
	return FALSE;
}
int recover_env_id_status(char *msg,unsigned int * env_id)
{
	if (msg == NULL) return FALSE; //strtok
	
	int nLength = strlen(msg);
        if (msg[nLength-1] == '\n') {
                msg[nLength-1] = '\0';
        }
        int found = FALSE;
        char * tok = strtok(msg, "\n");
        while (tok != NULL) {
                if (sscanf(tok,"Location: http://www.pachube.com/api/feeds/%d",env_id)==1)
                {
                        found = TRUE;
                        break;
                }
                tok = strtok(NULL,"\n");
        }
        if (found) printf("Environment id %d created\n",*env_id);
        

	return found;

}
int recover_trigger_id_status(char * msg,unsigned int * tr_id)
{
	if (msg == NULL) return FALSE; //strtok


	printf("msg = %s\n",msg);
	
	int nLength = strlen(msg);
        if (msg[nLength-1] == '\n') {
                msg[nLength-1] = '\0';
        }
        int found = FALSE;
        char * tok = strtok(msg, "\n");
        while (tok != NULL) {
                if (sscanf(tok,"Location: http://www.pachube.com/api/triggers/%d",tr_id)==1)
                {
                        found = TRUE;
                        break;
                }
                tok = strtok(NULL,"\n");
        }
        if (found) printf("Trigger id %d created\n",*tr_id);
        

	return found;

}
int find_in_http(char *msg, char *tag, int * position)
{
	int i = 0;
	int j = 0;
	int tagL = strlen(tag);

	if ((msg == NULL) || (tag ==NULL)) return FALSE;


	while (msg[i]!='\0')
	{
		if (msg[i] != tag [j])
			j = 0;
		else
		{
			j++;
			if (j==tagL) //found
			{
				* position = i - tagL + 1;
				return TRUE;
			}
		}
		i++;
	}
	return FALSE;
}
int recover_env_from_http(char *msg, char *environment)
{

	if (msg == NULL) return FALSE;

	int offset =0;
	
	if (!find_in_http(msg,"<?xml",&offset)) return FALSE;

	//found:
	sprintf(environment,"%s",msg+offset);
	return TRUE;


}


/*PUBLIC FUNCTIONS*/

/*Realtime data, AUTH*/
//environmet related:

/**
* create a new environment: if eeml data is NULL it creates a default one.
**/
int create_environment(char *api_key, char *environment, unsigned int *env_id) //POST
{

	char data_header[MSG_MAX];
	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;
	
	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);
	headers = curl_slist_append(headers, "Expect:");
//	headers = curl_slist_append(headers, "Content-Type:");

	//create url:
	sprintf(url,"http://www.pachube.com/api/feeds/");
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	//data header handler : if i change order i cant get data_header ??????
   	data_header[0]='\0';
	curl_easy_setopt(curl, CURLOPT_WRITEHEADER, data_header);
	curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, write_data_to_string);

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, environment);

	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned:200 is ok
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);

	//TODO process data_body and find new trigger_id or maybe online inside write_handler_function
	printf("data_header___\n%s________\n",data_header);

	//if (!recover_trigger_id_status(msg,&(trigger->tr_id))) return FALSE;
	return TRUE;	


}
/**
* delete an env_id environment
*/
int delete_environment(unsigned int env_id,char * api_key) //DELETE
{

//CURLOPT_CUSTOMREQUEST: custom header for DELETE method

	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
//	char custom_request[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;

//	sprintf(custom_request,"%s","DELETE"); //http method
	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);
	//other way, not sure if works (avoid adding header list)
	//sprintf(custom_request,"DELETE /api/triggers/%d HTTP/1.1\r\nHost: %s\r\nX-PachubeApiKey: %s\r\n\r\n",trigger_id, HOST, api_key);

	//create url:
	sprintf(url,"http://www.pachube.com/api/feeds/%d",env_id);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom http method
	curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "DELETE");
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

  	//query pachube
	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned value: 200 is ok with delete
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);
	
	return TRUE;


}

/**
* get xml env_id environment information
* returns xml body as string
*/
int get_environment(unsigned int env_id, char * api_key, char *environment,data_format_tp format) //GET
{


	char format_str [STR_LEN];	
	if (!data_format_str(format,format_str)) return FALSE;



	char data_body[MSG_MAX];
	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;

	if ((format=!XML)&&(format!=JSON)) return FALSE;
	

	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);

	//create url:
	sprintf(url,"http://www.pachube.com/api/feeds/%d.%s",env_id,format_str);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	//data body handler 
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data_to_string);
   	data_body[0]='\0';
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, data_body);
	
	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);

	//TODO size control 
	sprintf(environment,"%s",data_body);
	
	return TRUE;

}
/*
* update enviroment: datastreams or info
*/
int update_environment(unsigned int env_id, char *api_key, char *environment,data_format_tp format) //PUT
{
	
	char * format_str = data_format_tp_str[format]; 

//printf("formato dice: %s , tipo: %d\n",format_str,format);

	if ((format=!XML)&&(format!=CSV)) return FALSE; 

	char data_header[MSG_MAX];
	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;
	

	char tam[100];
	sprintf(tam,"Content-Length: %d",strlen(environment));

	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);
	headers = curl_slist_append(headers, tam);
	headers = curl_slist_append(headers, "Expect:");
	headers = curl_slist_append(headers, "Content-Type: type/text");
//	headers = curl_slist_append(headers, "Content-Type:");

	//create url:
	sprintf(url,"http://www.pachube.com/api/feeds/%d.%s",env_id,format_str);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

	curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	//data header handler : if i change order i cant get data_header ??????
   	data_header[0]='\0';
	curl_easy_setopt(curl, CURLOPT_WRITEHEADER, data_header);
	curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, write_data_to_string);

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS,environment);

	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned:200 is ok
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);

	//TODO process data_body and find new trigger_id or maybe online inside write_handler_function
	printf("data_header___\n%s________\n",data_header);

	//if (!recover_trigger_id_status(msg,&(trigger->tr_id))) return FALSE;
	return TRUE;	


}

//datastream functions

//Creates a new datastream in environment [environment ID]. 
//The body of the request should contain EEML of the environment to be created 
//and at least one datastream. 
int create_datastream(unsigned int env_id, char *api_key, char *environment) //POST
{

	char data_header[MSG_MAX];
	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;
	
	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);
	headers = curl_slist_append(headers, "Expect:");
//	headers = curl_slist_append(headers, "Content-Type:");

	//create url:
	sprintf(url,"http://www.pachube.com/api/feeds/%d/datastreams/",env_id);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	//data header handler : if i change order i cant get data_header ??????
   	data_header[0]='\0';
	curl_easy_setopt(curl, CURLOPT_WRITEHEADER, data_header);
	curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, write_data_to_string);

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, environment);

	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned:200 is ok
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);

	//TODO process data_body and find new trigger_id or maybe online inside write_handler_function
	printf("data_header___\n%s________\n",data_header);

	//if (!recover_trigger_id_status(msg,&(trigger->tr_id))) return FALSE;
	return TRUE;	

}
int delete_datastream(unsigned int env_id, int ds_id, char *api_key) //DELETE
{

//CURLOPT_CUSTOMREQUEST: custom header for DELETE method

	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
//	char custom_request[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;

//	sprintf(custom_request,"%s","DELETE"); //http method
	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);
	//other way, not sure if works (avoid adding header list)
	//sprintf(custom_request,"DELETE /api/triggers/%d HTTP/1.1\r\nHost: %s\r\nX-PachubeApiKey: %s\r\n\r\n",trigger_id, HOST, api_key);

	//create url:
	sprintf(url,"http://www.pachube.com/api/feeds/%d/datastreams/%d",env_id,ds_id);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom http method
	curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "DELETE");
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

  	//query pachube
	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned value: 200 is ok with delete
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);
	
	return TRUE;



}
int get_datastream(unsigned int env_id,int ds_id,char *api_key, char *datastream, data_format_tp format) //GET
{

	char data_body[MSG_MAX];
	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;

	if ((format=!XML)&&(format!=JSON)) return FALSE;
	

	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);

	//create url:
	sprintf(url,"http://www.pachube.com/api/feeds/%d/datastreams/%d.xml",env_id,ds_id);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	//data body handler 
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data_to_string);
   	data_body[0]='\0';
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, data_body);
	
	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);

	//TODO size control 
	sprintf(datastream,"%s",data_body);
	
	return TRUE;

}
int update_datastream(unsigned int env_id,int ds_id, char *api_key, char *datastream,data_format_tp format) //PUT
{

	char data_header[MSG_MAX];
	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;
	

	char tam[100];
	sprintf(tam,"Content-Length: %d",strlen(datastream));

	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);
	headers = curl_slist_append(headers, tam);
	headers = curl_slist_append(headers, "Expect:");
	headers = curl_slist_append(headers, "Content-Type: type/text");
//	headers = curl_slist_append(headers, "Content-Type:");

	//create url:
	sprintf(url,"http://www.pachube.com/api/feeds/%d/datastreams/%d.csv",env_id,ds_id);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

	curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	//data header handler : if i change order i cant get data_header ??????
   	data_header[0]='\0';
	curl_easy_setopt(curl, CURLOPT_WRITEHEADER, data_header);
	curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, write_data_to_string);

	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, datastream);

	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned:200 is ok
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);

	//TODO process data_body and find new trigger_id or maybe online inside write_handler_function
	printf("data_header___\n%s________\n",data_header);

	//if (!recover_trigger_id_status(msg,&(trigger->tr_id))) return FALSE;
	return TRUE;	

}


//triggers functions:
int create_trigger(trigger_tp * trigger,char *api_key) //POST
{

	char data_header[MSG_MAX];
	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;
	char body[MSG_MAX];

	
	char type_str[STR_LEN];
 	sprintf(type_str,"%s",trigger_tp_str[trigger->type]);
	printf("tipo trigger vale %d\n",trigger->type);

	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);
	headers = curl_slist_append(headers, "Expect:");
//	headers = curl_slist_append(headers, "Content-Type:");

	//create url:
	sprintf(url,"%s","http://www.pachube.com/api/triggers/");
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	//data header handler : if i change order i cant get data_header ??????
   	data_header[0]='\0';
	curl_easy_setopt(curl, CURLOPT_WRITEHEADER, data_header);
	curl_easy_setopt(curl, CURLOPT_HEADERFUNCTION, write_data_to_string);

	//create post form:
	sprintf(body,"trigger[url]=%s&trigger[trigger_type]=%s&trigger[threshold_value]=%d&trigger[environment_id]=%d&trigger[stream_id]=%d",trigger->url,type_str,trigger->threshold,trigger->env_id,trigger->ds_id);
	 curl_easy_setopt(curl, CURLOPT_POSTFIELDS, body);

	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned:200 is ok
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);

	//TODO process data_body and find new trigger_id or maybe online inside write_handler_function
	printf("data_header___\n%s________\n",data_header);

	//if (!recover_trigger_id_status(msg,&(trigger->tr_id))) return FALSE;
	return TRUE;	

}


//TODO i dunno what to do with format??? header info unknown!
int get_all_triggers(data_format_tp format, char *api_key, char *trigger_list) //GET
{

	char data_body[MSG_MAX];
	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;

	if ((format=!XML)&&(format!=JSON)) return FALSE;

	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);

	//create url:
	sprintf(url,"%s","http://www.pachube.com/api/triggers/");
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	//data body handler 
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data_to_string);
   	data_body[0]='\0';
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, data_body);
	
	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned:200 is ok
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);

	//TODO size control 
	sprintf(trigger_list,"%s",data_body);
	
	return TRUE;


}


int update_trigger(trigger_tp *trigger, char *api_key)//PUT
{

	char msg[MSG_MAX];
	char body[MSG_MAX];
	int fd;

	char *type_str = trigger_tp_str[trigger->type];


	//this time, body 1
	//like post, 501 server error
	sprintf(body,"trigger[url]=%s&trigger[trigger_type]=%s&trigger[threshold_value]=%d&trigger[environment_id]=%d&trigger[stream_id]=%d",trigger->url,type_str,trigger->threshold,trigger->env_id,trigger->ds_id);
	//like xml:

/*<?xml version="1.0" encoding="UTF-8"?>
<datastream-trigger>
  <id type="integer">82</id>
  <url>http://www.postbin.org/zq17vl</url>
  <trigger-type>change</trigger-type>
  <threshold-value type="float">5</threshold-value>
  <notified-at type="datetime">2009-12-19T17:09:46Z</notified-at>
  <user>min0n</user>
  <environment-id type="integer">3975</environment-id>
  <stream-id>0</stream-id>
</datastream-trigger>*/

sprintf(body,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n<datastream-trigger>\r\n<id type=\"integer\">%d</id>\r\n<url>%s</url>\r\n<trigger-type>%s</trigger-type><threshold-value type=\"float\">%d</threshold-value>\r\n<environment-id type=\"integer\">%d</environment-id>\r\n<stream-id>%d</stream-id>\r\n</datastream-trigger>",trigger->tr_id,trigger->url,type_str,trigger->threshold,trigger->env_id,trigger->ds_id);



	printf("body vale %s\n",body);

	int post_l = strlen(body);

	//add header to msg:
	sprintf(msg,"PUT /api/triggers/%d HTTP/1.1\r\nHost: %s\r\nX-PachubeApiKey: %s\r\nContent-Length: %d\r\nConnection: close\r\n\r\n%s",trigger->tr_id,HOST, api_key, post_l, body);




	if (!connect_server(&fd)) return FALSE;

	if (!send_data(fd,msg,strlen(msg)+1)) return FALSE;

	if (!read_data(fd, msg)) return FALSE;

	if (!recover_trigger_id_status(msg,&(trigger->tr_id))) return FALSE;
	
	disconnect_server(fd);

	return TRUE; //created, tr_id returned

}
//TODO: not sure if i need to add Content-Length: %d, and Connection: close to ALL CURL HEADERS ??
int get_trigger(int trigger_id, data_format_tp format, char *api_key, char *trigger)//GET
{

	char data_body[MSG_MAX];
	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;

	if ((format=!XML)&&(format!=JSON)) return FALSE;
	

	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);

	//create url:
	sprintf(url,"http://www.pachube.com/api/triggers/%d",trigger_id);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

	//data body handler 
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data_to_string);
   	data_body[0]='\0';
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, data_body);
	
	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);

	//TODO size control 
	sprintf(trigger,"%s",data_body);
	
	return TRUE;


}

int delete_trigger(int trigger_id, char *api_key) //DELETE
{


	//CURLOPT_CUSTOMREQUEST: custom header for DELETE method

	CURL *curl;
	CURLcode res;
  	char url[STR_LEN];
//	char custom_request[STR_LEN];
  	char api_key_header[STR_LEN];
	struct curl_slist *headers=NULL;

//	sprintf(custom_request,"%s","DELETE"); //http method
	//create header_strings and add to list
	sprintf(api_key_header,"X-PachubeApiKey: %s",api_key);
	headers = curl_slist_append(headers, api_key_header);
	//other way, not sure if works (avoid adding header list)
	//sprintf(custom_request,"DELETE /api/triggers/%d HTTP/1.1\r\nHost: %s\r\nX-PachubeApiKey: %s\r\n\r\n",trigger_id, HOST, api_key);

	//create url:
	sprintf(url,"http://www.pachube.com/api/triggers/%d",trigger_id);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set custom http method
	curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "DELETE");
	//set custom header  
  	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

  	//query pachube
	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned value: 200 is ok with delete
	//DEBUG
	printf("val vale %ld\n",val);

  	// always cleanup
	curl_easy_cleanup(curl);
	
	return TRUE;

}
/*Historical data, NO_AUTH*/
int get_historical_datastream_csv(int env_id,int ds_id, char *file_name) //GET
{

	CURL *curl;
	CURLcode res;
	
	FILE * bodyfile;

  	char url[STR_LEN];

	//create url:
	sprintf(url,"http://www.pachube.com/feeds/%d/datastreams/%d/history.csv",env_id,ds_id);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

	//handler for get:
  	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION , write_data);

	bodyfile = fopen(file_name,"w"); //archive_file
	if (bodyfile == NULL) {
	    curl_easy_cleanup(curl);
	    return FALSE;
	  }

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set get handler to archive_file
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, bodyfile);

	
  	//query pachube
	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned value 200 is ok.
	//maybe delete downloaded file?
	//DEBUG
	printf("val vale %ld\n",val);

	fclose(bodyfile);

  	// always cleanup
	curl_easy_cleanup(curl);
	
	return TRUE;

}
/*
int get_historical_datastream_png(int env_id,int ds_id, graph_tp graph,char *file_name) //GET
{

}
*/
int get_archive_datastream_csv(int env_id, int ds_id, char *file_name) //GET
{
	CURL *curl;
	CURLcode res;
	
	FILE * bodyfile;

  	char url[STR_LEN];

	//create url:
	sprintf(url,"http://www.pachube.com/feeds/%d/datastreams/%d/archive.csv",env_id,ds_id);
	
	//curl init
	curl = curl_easy_init();
	if (!curl) return FALSE;

	//handler for get:
  	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION , write_data);

	bodyfile = fopen(file_name,"w"); //archive_file
	if (bodyfile == NULL) {
	    curl_easy_cleanup(curl);
	    return FALSE;
	  }

  	//set url
	curl_easy_setopt(curl, CURLOPT_URL, url);
	 
	//DEBUG
	curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
  
	//set get handler to archive_file
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, bodyfile);

	
  	//query pachube
	res = curl_easy_perform(curl);
	//DEBUG
	printf("http code %s\n",curl_easy_strerror(res));

	//Server returned code : 201, 401,...
	if (res != CURLE_OK) return FALSE; //error
	
	long val;
	res = curl_easy_getinfo(curl,CURLINFO_RESPONSE_CODE,&val);

	//TODO process returned value 200 is ok.
	//maybe delete downloaded file?
	//DEBUG
	printf("val vale %ld\n",val);

	fclose(bodyfile);

  	// always cleanup
	curl_easy_cleanup(curl);
	
	return TRUE;

}




