/***********************************************************************
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
( at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
ERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
Online: http://www.gnu.org/licenses/gpl.txt
***********************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include <string.h>
#include "../include/pachulib.h"

typedef enum
{
	FEED,
	DATASTREAM,
	TRIGGER,
	HISTORICAL,
	ARCHIVE
} object_tp;



void err_and_exit(char *msg);
void err_and_exit(char *msg)
{
	perror(msg);

	printf("________________________________________________________________\n");
	printf("cachulix: pachube linux c client\n");
	printf("________________________________________________________________\n");
	printf("./cachulix <action><object> [api-key][id][ds_id][file]\n");
	printf("action: --create|-c, --get|-g, --update|-u, --delete|-d\n");
	printf("object: feed|f, datastream|d, trigger|t, historical|h, archive|a\n");
	printf("api-key: --key|-k <key>\n");
	printf("id: --id|-i <id>\n");
	printf("ds_id: --ds_id|-s <ds_id>\n");
	printf("file: --file|-f <path_to_file>\n");
	printf("________________________________________________________________\n");


	exit(-1);
}

int get_object(char * object_str, int * obj);
int get_object(char * object_str, int * obj)
{
	
	if ((strcasecmp(object_str,"FEED")==0)||(strcasecmp(object_str,"F")==0))
		* obj = FEED;
	else if ((strcasecmp(object_str,"DATASTREAM")==0)||(strcasecmp(object_str,"D")==0))
		* obj = DATASTREAM;
	else if ((strcasecmp(object_str,"TRIGGER")==0)||(strcasecmp(object_str,"T")==0))
		* obj = TRIGGER;
	else if ((strcasecmp(object_str,"HISTORICAL")==0)||(strcasecmp(object_str,"H")==0)) //get
		* obj = HISTORICAL;
	else if ((strcasecmp(object_str,"ARCHIVE")==0)||(strcasecmp(object_str,"A")==0)) //get
		* obj = ARCHIVE;
	else
		return 0;

	return 1;

}

int main (int argc, char ** argv)
       {
         int c;
         //int digit_optind = 0;
	 int action = -1;
	 int obj = -1;
	char * api_key = NULL;
	char * file_name = NULL;
	unsigned int id = -1;
	unsigned int ds_id = -1;

         while (1)
           {
             //int this_option_optind = optind ? optind : 1;
             int option_index = 0;
             static struct option long_options[] =
             {
               {"create", 1, 0, 0},
               {"update", 1, 0, 1},
               {"get", 1, 0, 2},
               {"delete", 1, 0, 3},
               {"file", 1, 0, 4},
               {"id", 1, 0, 5},
               {"key", 1, 0, 6},
               {"help", 1, 0, 7},
               {"ds_id", 1, 0, 8},
               {0, 0, 0, 0}
             };

             c = getopt_long (argc, argv, "c:u:g:d:f:i:k:hs:",
                        long_options, &option_index);
             if (c == -1)
            break;
	     printf("optind vale %d\n",optind);

             switch (c)
               {
	       case 0:
               case 'c':
		 if (action!=-1) err_and_exit("duplicated action");
		 action = POST;
		 if (!get_object(optarg,&obj)) err_and_exit("source type unkown");
                 //printf ("create `%s'\n", optarg);
                 break;

	       case 1:
               case 'u':
		 if (action!=-1) err_and_exit("duplicated action");
		 action = PUT;
		 if (!get_object(optarg,&obj)) err_and_exit("source type unkown");
//                 printf ("update `%s'\n", optarg);
                 break;

	       case 2:
               case 'g':
		 if (action!=-1) err_and_exit("duplicated action");
		 action = GET;
		 if (!get_object(optarg,&obj)) err_and_exit("source type unkown");
                 //printf ("get  `%s'\n", optarg);
                 break;

	       case 3:
               case 'd':
		 if (action!=-1) err_and_exit("duplicated action");
		 action = DELETE;
		 if (!get_object(optarg,&obj)) err_and_exit("source type unkown");
                 //printf ("delete `%s'\n", optarg);
                 break;
	       
		case 4:
               case 'f':
	         if (file_name!=NULL) err_and_exit("duplicated file");
		 file_name = malloc(strlen(optarg)+1);
		 sprintf(file_name,"%s",optarg);
             //    printf ("file `%s'\n", optarg);
                 break;
		
	       case 5:
               case 'i':
	         if (id != -1) err_and_exit("duplicated id");
//                 printf ("id `%s'\n", optarg);
		 id = atoi(optarg);
                 break;
	       
		case 6:
               case 'k':
	         if (api_key!=NULL) err_and_exit("duplicated api-key");
		 api_key = malloc(strlen(optarg)+1);
		 sprintf(api_key,"%s",optarg);
//                 printf ("api-key `%s'\n", optarg);
                 break;
		case 7:
               case 'h': printf("help needed\n");
                 break;
	       case 8:
               case 's':
	         if (ds_id != -1) err_and_exit("duplicated ds_id");
//                 printf ("id `%s'\n", optarg);
		 ds_id = atoi(optarg);
                 break;

               case '?': printf("? needed\n");
			err_and_exit("help");
                 break;

               default:
                 printf ("?? getopt returned character code 0%o ??\n", c);
			err_and_exit("help");
               }
           }

         if (optind < argc)
           {
             printf ("non-option ARGV-elements: ");
             while (optind < argc)
             printf ("%s ", argv[optind++]);
             printf ("\n");
	     err_and_exit("help");
           }


	if ((obj==-1)||(action==-1)) err_and_exit("undefined action or source type");

	printf("command:%d obj=%d id=%d file=%s api_key=%s\n",action,obj,id,file_name,api_key);

	char file_str[MSG_MAX];
	file_str[0] = '\0';
	data_format_tp format = XML;
	if (action == POST) //create 
	{
		if (file_name == NULL) err_and_exit("input file needed");
		if (api_key == NULL) err_and_exit("api_key needed");
	//	if (id == -1) err_and_exit("id needed");

		if (!load_file(file_name,file_str)) err_and_exit("cant load file");
	//		printf("contenido fichero____\n%s___________\n",file_str);
	//	else err_and_exit("cant load file");
		
		if ( obj == FEED)
		{
			printf("creating new environment...");
			if (create_environment(api_key,file_str,&id))
		                printf("OK\n");
		        else printf("NOK\n");


		}else if ( obj == DATASTREAM)
		{	
			if (id == -1) err_and_exit("id needed");
			printf("creating new datastream...");
			if(create_datastream(id,api_key,file_str))
		                printf("OK");
		        else printf("NOK\n");


		}else if ( obj == TRIGGER) //form???
		{
			printf("TODO: CREATE TRIGGER\n");
//			printf("creating new trigger...");
		
		}
		
	}else if (action == GET) //retrieve information
	{

		if (obj == FEED)
		{
			if (api_key == NULL) err_and_exit("api_key needed");
			if (id == -1) err_and_exit("id needed");

			printf("get feed...");
			printf("file_name vale %s.\n",file_name);
		        if (get_environment(id,api_key,file_str,XML))
		        {
				if (file_name!=NULL) save_file(file_name, file_str);
                		printf("OK:environment:\n%s\n",file_str);
		        }
		        else printf("NOK\n");

		}else if (obj == DATASTREAM)
		{
			if (api_key == NULL) err_and_exit("api_key needed");
			if (id == -1) err_and_exit("id needed");
			if (ds_id == -1) err_and_exit("ds_id needed");

			format = XML;
			if (file_name!=NULL) format = get_format_file(file_name); 

			printf("get datastream...");
			if (get_datastream(id,ds_id,api_key,file_str,format))
			{
				if (file_name!=NULL) save_file(file_name, file_str);
		                printf("OK\n");
			}
		        else printf("NOK\n");


		}else if (obj == TRIGGER)
		{
			if (api_key == NULL) err_and_exit("api_key needed");
			//if (id == -1) err_and_exit("id needed");
			//without id get all triggers
			if (id!=-1)
			{
				printf("get trigger...");
				if (get_trigger(id, XML,api_key, file_str))
				{
					if (file_name!=NULL) save_file(file_name, file_str);
			                printf("OK\n");
				}
			        else printf("NOK\n");
			}else //id==-1
			{
				printf("get all triggers...");
				if (get_all_triggers(XML, api_key,file_str))
        			{
					if (file_name!=NULL) save_file(file_name, file_str);
			                printf("OK\n"); 
			        }else printf("NOK\n");

			}
		}else if (obj == HISTORICAL) //no-auth
		{
			if (file_name==NULL) err_and_exit("csv file needed");
			if (id == -1) err_and_exit("id needed");
			if (ds_id == -1) err_and_exit("ds_id needed");

//			if (get_format(file_name)!=CSV) err_and_exit("csv file needed");

			printf("get historical datastream to file...");
			if (get_historical_datastream_csv(id,ds_id, file_name))
		        {
                		printf("OK\n"); 
		        }else printf("NOK\n");
			
		}else if (obj == ARCHIVE) //no-auth
		{
			if (file_name==NULL) err_and_exit("csv file needed");
			if (id == -1) err_and_exit("id needed");
			if (ds_id == -1) err_and_exit("ds_id needed");

			printf("get archive datastream to file...");
			if (get_archive_datastream_csv(id,ds_id, file_name))
		        {
                		printf("OK\n"); 
		        }else printf("NOK\n");
		}	
	}else if (action == PUT) //update information
	{
		if (file_name == NULL) err_and_exit("input file needed");
		if (api_key == NULL) err_and_exit("api_key needed");

		if (obj == FEED)
		{
			if (id == -1) err_and_exit("id needed");
			format = get_format_file(file_name);
			if ((format!=CSV)&&(format!=XML)) err_and_exit("csv/xml file needed");
			if (!load_file(file_name,file_str)) err_and_exit("cant load file");
			printf("update feed...");
			if (update_environment(id,api_key,file_str,format))
	                	printf("OK\n");
		        else printf("NOK\n");
		}else if (obj == DATASTREAM)
		{

			if (id == -1) err_and_exit("id needed");
			if (ds_id == -1) err_and_exit("ds_id needed");
			format = get_format_file(file_name); //TODO change function: get_format returns XML as default when unrecognised format
			if ((format!=CSV)&&(format!=XML)) err_and_exit("csv/xml file needed");
			if (!load_file(file_name,file_str)) err_and_exit("cant load file");
			printf("update datastream...");
			if (update_datastream(id,ds_id,api_key,file_str,format))
		                printf("OK\n");
		        else printf("NOK\n");


		}else if (obj == TRIGGER)
		{
			//TODO
			printf("TODO: UPDATE TRIGGER\n");
		}
	}else if (action == DELETE) //delete it
	{

		if (api_key == NULL) err_and_exit("api_key needed");
		if (id == -1) err_and_exit("id needed");

		if ( obj == FEED )
		{
			printf("delete feed...");
			if (delete_environment(id,api_key))
		                printf("OK\n");
		        else printf("NOK\n");

		}else if ( obj == DATASTREAM )
		{
			if (ds_id == -1) err_and_exit("ds_id needed");
			printf("delete datastream...");
			if(delete_datastream(id,ds_id,api_key))
		                printf("OK");
		        else printf("NOK\n");
		}else if ( obj == TRIGGER )
		{

			printf("delete trigger...");
			if (delete_trigger(id,api_key))
		                printf("OK\n");
		        else printf("NOK\n");
		
		}

	}




         exit (0);
       }

