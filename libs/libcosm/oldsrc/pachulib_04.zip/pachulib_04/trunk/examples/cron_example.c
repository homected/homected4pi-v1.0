/***********************************************************************
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
( at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
ERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
Online: http://www.gnu.org/licenses/gpl.txt
***********************************************************************/

/*
	debug code :: 
	
	read values from system files and upload
	it works as a cron job
	dirty bits 4d4
*/
#include <stdio.h>
#include <unistd.h>
#include "../include/pachulib.h"
#include "../include/tiempo.h"




int main(void)
{


	
	
	char api_key[KEY_LEN];
	char ds[MSG_MAX];

	/* Edit it*/
	unsigned int env_id = 0; //your-feed

	sprintf(api_key,"your-api-key");
	printf("edit first\n");
	exit(-1);

	FILE *ifp, *ofp;
	char *mode = "r";
	int found = FALSE;
	ifp = fopen("/proc/meminfo", mode);

	if (ifp == NULL) {
	  fprintf(stderr, "Can't open input file in.list!\n");
	  exit(1);
	}

	char outputFilename[] = "/var/log/pachuli.txt";
	ofp = fopen(outputFilename, "a+");

	if (ofp == NULL) {
	  fprintf(stderr, "Can't open output file %s!\n",
	          outputFilename);
	  exit(1);
	}
	char fin_mem[100000];
	

	int c;
	int i = 0;
	int j = 0;

		unsigned long long int ahora_; 
		char cad[200];
		//fichero en memoria
		while ( (c = getc(ifp) ) != EOF ) 
		{
			fin_mem[i] = c;
			printf("%c",fin_mem[i]);
			i++;

		}
		fin_mem[i] = '\0';

		j= 0;

		//tokenizo : busco valores
		int mem_free=0;
		int swap_free=0;
		char * tok = strtok(fin_mem, "\n");
	        while (tok != NULL) 
		{
                	if (sscanf(tok,"MemFree:          %d kB",&mem_free)==1)
                	{
                        	j++;
				if (j==2)
				{
					found = TRUE;
	                        	break;
				}
                	}else if ((sscanf(tok,"SwapFree:        %d kB",&swap_free)==1))
			{
                        	j++;
				if (j==2)
				{
					found = TRUE;
	                        	break;
				}
			}
                
			tok = strtok(NULL,"\n");
        	}
		//envio a pachube
	        if (found){
				//upload
				sprintf(ds,"%d,%d",mem_free,swap_free);
				ahora_ = ahora();
				hora_a_cad(ahora_,cad);
				fprintf(ofp,"%s enviando nueva muestra: %s..",cad,ds);
				if (update_environment(env_id,api_key,ds,CSV))
				{
					fprintf(ofp,"..OK\n");
				}
				else {fprintf(ofp,"..NOK\n");
					}
		}
		//cierro ficheros	
		fclose(ifp);
		fclose(ofp);
	}


