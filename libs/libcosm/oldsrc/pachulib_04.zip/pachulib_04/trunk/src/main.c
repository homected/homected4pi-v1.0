/***********************************************************************
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
( at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
ERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
Online: http://www.gnu.org/licenses/gpl.txt
***********************************************************************/

/*
	debug code :: 
	some examples inside comments.
	dirty bits 4d4
*/
#include <stdio.h>
#include <unistd.h>
#include "../include/pachulib.h"




int main(void)
{



	
	char api_key[KEY_LEN];
	char ds[MSG_MAX];

	/* Edit it*/
	unsigned int env_id = 3975; //your-feed
	unsigned int ds_id = 0; //a datastream

	
	
	
	sprintf(api_key,"%s","enter-your-api-key");
	printf("Edit main.c first\n");
	exit(-1);


	//TEST : create a new environment:
/*
	char environment[MSG_MAX];

	sprintf(environment,"%s","<eeml xmlns=\"http://www.eeml.org/xsd/005\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.eeml.org/xsd/005 http://www.eeml.org/xsd/005/005.xsd\"><environment><title>otro2</title></environment></eeml>");

	if (create_environment(api_key,environment,&env_id))
		printf("OK\n");
	else	printf("NOK\n");
*/	

	//TEST : delete environment:
/*
	if (delete_environment(env_id,api_key))
		printf("OK\n");
	else printf("NOK\n");
*/
	//TEST: get environment

/*
	char environment[MSG_MAX];
	data_format_tp f = XML;
	if (get_environment(env_id,api_key,environment,f))
	{
		printf("OK:environment:\n%s\n",environment);
	}
	else printf("NOK\n");
*/
	
	//TEST: update_environment:
	//XML
	/*
	sprintf(ds,"%s","<eeml xmlns=\"http://www.eeml.org/xsd/005\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.eeml.org/xsd/005 http://www.eeml.org/xsd/005/005.xsd\">\r\n<environment>\r\n<title>prueba 3</title>\r\n<description>description prueba 3</description>\r\n<location exposure=\"indoor\" domain=\"physical\" disposition=\"fixed\">\r\n<name>My Room</name>\r\n<lat>32.4</lat>\r\n<lon>22.7</lon>\r\n<ele>0.2</ele>\r\n</location>\r\n<data id=\"0\">\r\n<tag>temperature</tag>\r\n<value minValue=\"23.0\" maxValue=\"48.0\">25</value><unit symbol=\"C\" type=\"derivedSI\">Celsius</unit>\r\n</data>\r\n<data id=\"1\">\r\n<tag>dede</tag>\r\n<value minValue=\"1.0\" maxValue=\"38.0\">27</value><unit symbol=\"d\" type=\"derivedSI\">dddd</unit>\r\n</data>\r\n</environment>\r\n</eeml>");
	//sprintf(ds,"%s","<eeml xmlns=\"http://www.eeml.org/xsd/005\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.eeml.org/xsd/005 http://www.eeml.org/xsd/005/005.xsd\">\r\n<environment id=\"3975\">\r\n<title>prueba 3</title>\r\n</environment>\r\n</eeml>")
	if (update_environment(env_id,api_key,ds,XML))
		printf("OK\n");
	else printf("NOK\n");
*/


//TEST: update all datastreams for a while
/*
	float val1,val2;

	val1 = 32.23456;
	val2 = 12.323;
	unsigned int seed = 1;
	
	while (1)
	{
		val1 = 1 + (int) (50.0 * (rand() / (RAND_MAX + 1.0)));
		val2 = 1 + (int) (30.0 * (rand() / (RAND_MAX + 1.0)));
sprintf(ds,"%.2f,%.2f",val1,val2);
		printf("enviando nueva muestra: %s..",ds);
		if (update_environment(env_id,api_key,ds,CSV))
			printf("..OK\n");
		else printf("..NOK\n");
		sleep(100);
	}
*/



//TEST: update environment: all datastreams, csv:
/*
	sprintf(ds,"99");
	if (update_environment(env_id,api_key,ds,CSV))
		printf("OK\n");
	else printf("NOK\n");
*/


//TEST: update datastream 0 for a while
/*
	float val1;

	val1 = 32.23456;
	
	while (1)
	{
		val1 = 1 + (int) (50.0 * (rand() / (RAND_MAX + 1.0)));

		sprintf(ds,"%.2f",val1);
		printf("enviando nueva muestra: %s..",ds);
	ds_id= 2;
	if (update_datastream(env_id,ds_id,api_key,ds,CSV))
		printf("OK\n");
	else printf("NOK\n");

		sleep(100);
	}
*/



//TEST: update datastream csv
/*
	sprintf(ds,"99");
	ds_id= 2;
	if (update_datastream(env_id,ds_id,api_key,ds))
		printf("OK\n");
	else printf("NOK\n");
*/

//TEST: create datastream
/*
	sprintf(ds,"<eeml xmlns=\"http://www.eeml.org/xsd/005\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://www.eeml.org/xsd/005 http://www.eeml.org/xsd/005/005.xsd\">\r\n<environment>\r\n<data id=\"2\">\r\n<tag>dede</tag>\r\n<value minValue=\"13.332\" maxValue=\"248.232\">125.32</value><unit symbol=\"L\" type=\"derivedSI\">colo</unit>\r\n</data>\r\n</environment></eeml>");
	if(create_datastream(env_id,api_key,ds))
		printf("OK");
	else printf("NOK\n");	
*/
//TEST: delete datastream
/*
	if(delete_datastream(env_id,3,api_key))
		printf("OK");
	else printf("NOK\n");	
*/
//TEST: get datastream
/*
	data_format_tp format = XML;

	if (get_datastream(env_id,0,api_key,ds,format))
		printf("OK\n");
	else printf("NOK\n");
*/
//TEST get historical data
/*
	if (get_historical_datastream_csv(env_id,ds_id, "_historical.txt"))
	{
		printf("OK\n");	
	}else printf("NOK\n");
*/
//TEST get archive data
/*
	if (get_archive_datastream_csv(env_id,ds_id, "_archive.txt"))
	{
		printf("OK\n");	
	}else printf("NOK\n");
*/
//TEST get all triggers

/*
	if (get_all_triggers(XML, api_key,ds))
	{
		printf("OK\n");	
	}else printf("NOK\n");
*/
//TEST create trigger
/*
trigger_tp trigger;

	trigger.env_id = env_id;
	trigger.ds_id = 1;
	trigger.threshold = 5;
	trigger.type = CHANGE ;
	sprintf(trigger.url,"%s","http://www.postbin.org/zq17vl"); // using postbin webhook service
	trigger.tr_id = -1; 

	if (create_trigger(&trigger,api_key))
		printf("OK\n");
	else printf("NOK\n");

*/

//TEST get id trigger
/*
unsigned int t_id = 82;
	if (get_trigger(t_id, XML,api_key, ds))
		printf("OK\n");
	else printf("NOK\n");
*/
//TEST update trigger
//DOESNT WORK
/*
trigger_tp trigger;
trigger.env_id = env_id;
	trigger.ds_id = 0;
	trigger.threshold = 10000;
	trigger.type = GTE ;
	sprintf(trigger.url,"%s","http://www.postbin.org/zq17vl"); // using postbin webhook service
	trigger.tr_id = 82; 
	if (update_trigger(&trigger,api_key))
		printf("OK\n");
	else printf("NOK\n");
*/
//TEST DELETE TRIGGER
	if (delete_trigger(83,api_key))
		printf("OK\n");
	else printf("NOK\n");
}
