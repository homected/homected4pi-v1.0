const char* XAP_ME = "Rocket";
const char* XAP_SOURCE = "xAP-HUB"; 
const char* XAP_GUID = "FF000300";
const char* XAP_DEFAULT_INSTANCE = "Linux";

